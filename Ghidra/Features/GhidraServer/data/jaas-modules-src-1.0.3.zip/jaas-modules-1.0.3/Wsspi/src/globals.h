//==============================================================================
// File:		globals.h
//
// Description:	header file with global data declarations
//
// Revisions: 	Created: 11/24/1999
//
//==============================================================================
// Copyright(C) 1999, Tomas Restrepo. All rights reserved
//==============================================================================

#if !defined(WSSPI_GLOBALS)
#define WSSPI_GLOBALS


#endif // WSSPI_GLOBALS
