#!/bin/sh

java -cp dist/lib/hfsx.jar org.catacombae.hfsexplorer.tools.UnHFS "$@"
