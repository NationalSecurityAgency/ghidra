#!/bin/sh

cd dist
./hfsx.sh "$@"
