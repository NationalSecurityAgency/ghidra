#!/bin/sh

ant javadoc
