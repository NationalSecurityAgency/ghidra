#!/bin/sh

cd dist
./runfsb.sh "$@"
